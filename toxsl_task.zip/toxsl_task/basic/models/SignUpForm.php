<?php

namespace app\models;


//use common\models\User;
use Yii;
use yii\base\Model;

/**
 *SignUp Here.
 */
class SignUpForm extends Model
{
    public $username;
    public $email;
    public $password;
   
  

    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            // username and password are both required
            ['username', 'trim'],
            ['username', 'required'],
            ['email', 'trim'],
            ['email', 'required'],
            ['email', 'email'],
            ['password', 'required'],
            
        ];
    }

     public function signup()
     {
         
      // echo "ffcds";
      // exit;
        if (!$this->validate()) {
            return null;
        }
        $user  = new User();
        $user ->username = $this->username;
        $user ->email = $this->email; 
        $user ->password = $this->password;
        return $user->save() ? $user : null;
        
     }

   
}
