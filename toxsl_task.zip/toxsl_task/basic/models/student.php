<?php
namespace app\models;
 
use Yii;
 
class Student extends \yii\db\ActiveRecord
{
    public static function tableName()
    {
        return 'post';
    }
    public function rules()
    {
        return [
            [['title', 'description', 'image'], 'required'],
            
        ];
    }   
}

?>